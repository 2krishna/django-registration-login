from django import forms
from .models import MyUser
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm
 
 
 
#
 
class UserRegisterForm(UserCreationForm):
    
    class Meta:
        model =MyUser
        fields = ['name','email','gender','date']


class UserUpdateForm(forms.ModelForm):
    class Meta:
        model =MyUser
        fields = ['email','name','gender','status','date']

