from django.contrib import auth
from django.http.response import HttpResponse
from django.shortcuts import render,redirect

from django.views.decorators.csrf import csrf_exempt, csrf_protect
# Create your views here.
from .forms import UserRegisterForm,UserUpdateForm
from django.contrib import messages

from .models import MyUser
from django.contrib.auth import authenticate as Auth, login
from django.contrib.auth.decorators import login_required

from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.forms import PasswordChangeForm
#################### index#######################################
def index(request):
    return render(request, 'authenticate/index.html', {'title':'index'})

def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(data=request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, f'Your account has been created ! You are now able to log in')
            return redirect('index')
    else:
        form = UserRegisterForm()
    return render(request, 'authenticate/register.html', {'form': form, 'title':'reqister here'})

from django.contrib.auth.forms import AuthenticationForm

def Login(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            print('user',user)
            if user is not None:
                print('status',user.status)
                if user.status == "P":
                    messages.success(request, f'User Account Pending plz contact to admin after that are you able to login')
                    # login(request, user)
                    return redirect('index')
                if  user.status == 'A':
                    messages.success(request, f'User Account Activate  plz click to me ')
                    login(request, user)
                    return redirect('index')
                if  user.status == 'D':
                    messages.success(request, f'User Account De activate plz contact to admin after that are you able to login')
                    # login(request, user)
                    return redirect('index')
                # else:
                   
                #     messages.success(request, f'User Account Activate  plz click to me ')
                #     login(request, user)
                #     return redirect('index')
    else:
        form = AuthenticationForm()
    return render(request, 'authenticate/login.html', {'form': form})


    
def logout_request(request):
    auth.logout(request)
    messages.info(request, "Logged out successfully!")
    return redirect("/")

def delete_request(request):
    current_user=request.user
    current_user.delete()
    messages.info(request, "Delete user  successfully!")
    return redirect("/")

def update_profile(request):
    current_user=request.user
    context ={}
    print('id',current_user.id)
    myuser=MyUser.objects.get(id=current_user.id)
    form = UserUpdateForm(request.POST or None, instance = myuser)
 
    # save the data from the form and
    # redirect to detail_view
    if form.is_valid():
        form.save()
        messages.success(request, f'Your account has been created ! You are now able to log in')
        return redirect('/')
 
    # add form dictionary to context
    context["form"] = form
    return render(request, "authenticate/update.html", context)
    
def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user) 
            messages.success(request, 'Your password was successfully updated!')
            return redirect('index')
        else:
            messages.error(request, 'Please correct the error below.')
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'authenticate/change_password.html', {
        'form': form
    })