
from django.contrib.auth import logout
from django.urls import path, include
from django.conf import settings
from . import views
from django.conf.urls.static import static
 
urlpatterns = [
    path('', views.index, name ='index'),
    path('register/', views.register, name ='register'),
    path('login/', views.Login, name ='login'),
    path('logout/', views.logout_request, name ='logout'),
    path('delete/', views.delete_request, name ='delete'),
    path('update/', views.update_profile, name ='update'),
    path('update_password/', views.change_password, name='change_password'),
]